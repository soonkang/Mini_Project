package com.sp.mini_assignment.Interfaces;

import android.view.View;

public interface OnItemClickListener {
    void onItemClick(int position);
}

